package WordGame;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GuessWord game= new GuessWord();
		game.start();
		game.end();
	}
}
